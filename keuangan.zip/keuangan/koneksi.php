<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'keuangan';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>